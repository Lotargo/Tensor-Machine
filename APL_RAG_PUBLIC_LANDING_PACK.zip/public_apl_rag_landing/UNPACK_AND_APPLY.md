# Unpack and Apply Instructions

This archive contains the planning package for the future portable public landing directory of APL-RAG / Tensor Machine.

## Recommended use

1. Extract this archive in the root of `Lotargo/APL-RAG`.
2. Keep `public_apl_rag_landing/` private while drafting.
3. Later copy only public-safe files into a public portfolio / GitHub Pages repository.

## Shell

```bash
unzip APL_RAG_PUBLIC_LANDING_PACK.zip -d .
find public_apl_rag_landing -maxdepth 3 -type f | sort
```

## PowerShell

```powershell
Expand-Archive .\APL_RAG_PUBLIC_LANDING_PACK.zip -DestinationPath . -Force
Get-ChildItem .\public_apl_rag_landing -Recurse | Select-Object FullName
```

## Safety rule

Do not move private source code, exact implementation recipes, secrets, real endpoints, or local paths into this public landing package.
