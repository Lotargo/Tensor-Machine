# Appendix: APL-RAG Public Documentation Map

**Status:** planning appendix  
**Parent:** `APL_RAG_PUBLIC_EVIDENCE_AUDIT_TEMPLATE.md`  
**Purpose:** define the future public-safe technical dossier for APL-RAG / Tensor Machine.

---

## 0. Publication philosophy

The public package should be a technical dossier, not a product landing page.

It should be understandable to people who know RAG systems, vector search, agent tooling, data pipelines, Rust/server architecture, and performance constraints.

It should not be optimized for casual investors expecting a miracle product.

---

## 1. Proposed dossier structure

```text
Tensor Machine Public Technical Dossier
├── 00 Front Matter
├── 01 Architecture Overview
├── 02 Programmable Retrieval: DSL -> IR -> VM
├── 03 MCP Agent Integration
├── 04 Hybrid Retrieval and Signal Fusion
├── 05 Arrow / FlatBuffer / Zero-Copy Data Flow
├── 06 WebGPU and CPU/SIMD Execution Paths
├── 07 Structural Chunking and Knowledge Graph Metadata
├── 08 Observability and Operational Control
├── 09 Limitations and Open Problems
└── 10 Evidence Index
```

---

## 2. Document map

### `00_front_matter.md`

Purpose: define boundaries.

Include:

- what Tensor Machine is;
- what it is not;
- why source remains private;
- public evidence model;
- limitation-first framing.

### `01_architecture_overview.md`

Purpose: explain the three-layer architecture.

Sections:

- control plane / transport;
- declarative planning;
- tensor execution;
- local vs IPC mode;
- public/private boundary.

### `02_programmable_retrieval_dsl_vm.md`

Purpose: explain the central idea: retrieval strategies as programs.

Caution: do not publish full grammar or implementation recipes.

### `03_mcp_agent_integration.md`

Purpose: explain MCP-first design and agent readiness.

Include:

- tool surface at high level;
- sessions and ordered messages;
- LM Studio bridge as public-safe integration story.

### `04_hybrid_retrieval_signal_fusion.md`

Purpose: explain dense/BM25/entity/structural/recency/cluster signals.

Include diagrams and caveats.

### `05_arrow_flatbuffer_dataflow.md`

Purpose: explain Arrow-native / FlatBuffer response path.

Focus on data movement and copy reduction, not implementation internals.

### `06_webgpu_execution_paths.md`

Purpose: present CPU/SIMD + WebGPU as selectable execution paths.

Caution: require benchmark evidence before strong performance claims.

### `07_structural_chunking_graph_metadata.md`

Purpose: show RAG-specific depth: token-aware structural chunks, anchors, graph edges, entity metadata.

### `08_observability_operational_control.md`

Purpose: Prometheus, OpenTelemetry, health/readiness, rate limiting, circuit breakers, instruction limits.

### `09_limitations_open_problems.md`

Purpose: public credibility anchor.

Include:

- private implementation;
- incomplete external reproducibility;
- benchmark limitations;
- hardware/backend variability;
- operational hardening still in progress.

### `10_evidence_index.md`

Purpose: claim -> evidence -> caveat matrix.

---

## 3. Illustration plan

First diagrams:

- three-layer architecture;
- DSL -> IR -> bytecode -> VM;
- MCP request flow;
- hybrid signal fusion;
- Arrow/FlatBuffer pipeline;
- CPU/GPU backend selector;
- structural chunking hierarchy;
- observability/control plane.

Style: technical, wiki-like, restrained, diagram-first.
