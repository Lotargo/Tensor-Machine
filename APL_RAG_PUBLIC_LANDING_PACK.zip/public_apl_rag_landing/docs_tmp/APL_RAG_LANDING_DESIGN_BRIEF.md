# APL-RAG Landing Design Brief

**Status:** draft  
**Project:** APL-RAG / Tensor Machine  
**Purpose:** define a compact visual direction for a future portable public landing page.

---

## 1. Design intent

The landing should look like a **technical archive / systems engineering dossier**, not a startup pitch.

It should communicate:

- programmable RAG engine;
- closed-source implementation;
- public-safe architecture and evidence;
- serious engineering constraints;
- limitation-first credibility.

---

## 2. Visual direction

Recommended style:

> White wiki/documentation structure with optional dark technical archive mood.

Light theme should be the default because it supports long-form reading and wiki-like navigation.

Dark theme can be planned as a future option, borrowing colors from the Tensor Machine / systems-engineering vibe.

---

## 3. Layout

Suggested landing sections:

1. Boundary hero: what Tensor Machine is / is not.
2. Architecture map.
3. Publication map.
4. Evidence highlights.
5. Limitations first.
6. How to read this dossier.
7. Footer integrity note.

---

## 4. Components

Build first:

- metadata panel;
- architecture cards;
- documentation map cards;
- evidence cards;
- limitation callouts;
- diagram thumbnails;
- claim/evidence/caveat table.

Avoid:

- giant CTA buttons;
- fake benchmark graphs;
- generic AI-brain images;
- over-polished product-dashboard feeling;
- fundraising language.

---

## 5. Color and typography

Light theme:

- warm off-white background;
- graphite text;
- white cards with thin borders;
- muted teal/blue accent.

Dark theme tokens:

- near-black navy;
- dark slate panels;
- pale gray text;
- restrained cyan/teal accents.

Typography:

- large editorial title for `Tensor Machine`;
- readable body text;
- monospaced labels for evidence IDs, paths, config names, and logs.

---

## 6. Immediate decision

Start with a minimal static white documentation-style landing. Keep CSS tokens ready for a future dark mode.
