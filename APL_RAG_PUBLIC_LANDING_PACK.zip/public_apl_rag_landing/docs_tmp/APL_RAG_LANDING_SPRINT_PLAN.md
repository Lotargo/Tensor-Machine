# APL-RAG Landing Sprint Plan

**Status:** active sprint plan  
**Purpose:** track creation of the portable APL-RAG / Tensor Machine public landing package.

---

## 1. Supporting documents

| Document | Purpose | Status |
|---|---|---|
| `APL_RAG_PUBLIC_EVIDENCE_AUDIT_TEMPLATE.md` | Public-safe claims and evidence rules | Ready |
| `APL_RAG_PUBLIC_DOCUMENTATION_MAP_APPENDIX.md` | Publication map and dossier structure | Ready |
| `APL_RAG_LANDING_DESIGN_BRIEF.md` | Visual direction | Ready |
| `UNPACK_AND_APPLY.md` | How to unpack and apply this ZIP | Ready |

---

## 2. Sprint goals

### Goal A - Directory setup

- [ ] Extract ZIP in repository root.
- [ ] Verify `public_apl_rag_landing/` exists.
- [ ] Verify placeholders exist in all required directories.

### Goal B - Landing skeleton

- [ ] Create `index.html`.
- [ ] Create `styles/main.css`.
- [ ] Add light theme tokens.
- [ ] Add future dark theme tokens.

### Goal C - Content blocks

- [ ] Boundary hero.
- [ ] What Tensor Machine is / is not.
- [ ] Architecture map.
- [ ] Evidence highlights.
- [ ] Limitations.
- [ ] Documentation map.

### Goal D - Dossier pages

- [ ] `docs/00_front_matter.md`.
- [ ] `docs/01_architecture_overview.md`.
- [ ] `docs/02_programmable_retrieval_dsl_vm.md`.
- [ ] `docs/03_mcp_agent_integration.md`.
- [ ] `docs/04_hybrid_retrieval_signal_fusion.md`.
- [ ] `docs/09_limitations_open_problems.md`.
- [ ] `docs/10_evidence_index.md`.

### Goal E - Public-safety pass

- [ ] No private code.
- [ ] No secrets or real endpoints.
- [ ] No exact implementation recipes.
- [ ] No unsupported benchmark claims.
- [ ] Strong claims have caveats.

---

## 3. Definition of done

The package is ready when:

- `index.html` opens locally without build tools;
- all links are relative;
- all content is public-safe;
- the package can be copied to a public portfolio repository;
- the private APL-RAG repository remains undisclosed.
