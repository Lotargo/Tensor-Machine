# APL-RAG Planning Documents

This folder contains the planning documents for a future public-safe landing package.

These documents are not the public landing itself. They define what can be published, how the dossier should be organized, how it should look, and what tasks remain.
