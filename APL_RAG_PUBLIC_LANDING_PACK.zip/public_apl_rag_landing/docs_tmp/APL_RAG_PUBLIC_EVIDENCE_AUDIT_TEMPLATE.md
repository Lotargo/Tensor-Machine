# APL-RAG Public Evidence Audit Template

**Status:** working audit template  
**Repository:** `Lotargo/APL-RAG`  
**Public project name:** Tensor Machine  
**Created for:** selecting public-safe documentation and evidence for closed-source disclosure.

---

## 0. Purpose

This document is the working notebook for preparing a public evidence base for APL-RAG / Tensor Machine.

The code stays private. The public package should show what was built, which parts can be discussed safely, what evidence exists, and what remains incomplete.

Public materials should avoid detailed implementation recipes, private source paths, secrets, local endpoints, and anything that turns the private repository into a reproduction manual.

---

## 1. Disclosure levels

| Level | Meaning | Public treatment |
|---|---|---|
| **L0 - Private** | Reveals source logic, exact implementation, credentials, or sensitive operational details | Do not publish |
| **L1 - Internal Evidence** | Useful for internal confidence but not safe/ready publicly | Keep internal; summarize if needed |
| **L2 - Public Summary** | Can be described at high level | Publish as narrative/diagram |
| **L3 - Public Evidence** | Can be backed by logs, test summaries, diagrams, or configuration-safe evidence | Publish with caveats |
| **L4 - Public Dossier** | Strong enough for standalone technical article | Publish as full public-safe writeup |

---

## 2. Public positioning

Recommended public stance:

> Tensor Machine is a closed-source programmable RAG engine focused on retrieval planning, low-latency execution, MCP agent integration, Arrow/FlatBuffer data flow, hybrid relevance signals, and operational control. It is not presented as a finished universal RAG platform or a drop-in replacement for every framework.

Avoid saying:

- revolution;
- breakthrough;
- solved RAG;
- replacement for all RAG frameworks;
- production-ready unless a specific subsystem is actually hardened;
- open-source if the implementation is private.

Prefer:

- experimental engine;
- programmable retrieval;
- vector-relational execution system;
- public-safe technical evidence;
- closed-source implementation;
- validated subsystem;
- current limitations.

---

## 3. Candidate evidence lines

| Claim | Evidence source | Public status | Notes |
|---|---|---|---|
| Programmable retrieval via DSL -> IR -> bytecode -> VM | README architecture and feature sections | L3 | Good central narrative; avoid full DSL reproduction manual |
| MCP-first agent interface | README MCP tooling / integration sections | L3 | Show tool surface at high level |
| Arrow/FlatBuffer data flow | README abstract / zero-copy pipeline | L3 | Good performance-oriented evidence line |
| Hybrid retrieval signals | README hybrid search / RSF section | L3 | Good diagram/table candidate |
| WebGPU backend with CPU fallback | README GPU acceleration section | L2/L3 | Needs real benchmark/log evidence before strong claims |
| Observability and hardening | README observability section | L3 | Prometheus, OpenTelemetry, circuit breakers, instruction limits |
| Arrow Flight and sticky sessions | README network scaling section | L2/L3 | Present as architecture/foundation unless fully validated |
| Structural chunking + graph metadata | README chunking / graph sections | L3 | Strong for RAG-specific differentiation |

---

## 4. Public red lines

Do not publish:

- private source code;
- exact VM opcode implementation details beyond high-level summary;
- exact internal query-planning recipes;
- private endpoints, keys, `.env` values, local paths;
- benchmark claims without raw logs/configuration;
- statements implying the project replaces all RAG frameworks;
- security claims beyond what is actually tested.

---

## 5. Claim checklist

For each public claim, fill:

```md
### Claim

### Public-safe wording

### Evidence source(s)

### Evidence type
- [ ] README / public-safe architecture note
- [ ] raw log
- [ ] benchmark table
- [ ] test summary
- [ ] diagram
- [ ] limitation note

### What this proves

### What this does NOT prove

### Disclosure level

### Publication decision
```
