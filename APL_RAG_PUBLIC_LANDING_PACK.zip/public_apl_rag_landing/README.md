# Public APL-RAG Landing

This directory is the staging area for a future portable public landing package for APL-RAG / Tensor Machine.

It is designed to be copied/exported into a separate public portfolio or GitHub Pages repository without exposing the private source code.

## Rule

No private code, secrets, implementation recipes, or unsafe internal paths should be placed here.
